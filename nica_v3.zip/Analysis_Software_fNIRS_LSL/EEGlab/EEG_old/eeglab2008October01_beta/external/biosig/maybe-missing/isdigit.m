function b = isdigit(c) 

b = (c(1)>='0') & (c(1)<='9');

